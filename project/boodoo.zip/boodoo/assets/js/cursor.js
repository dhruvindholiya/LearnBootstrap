new kursor({
    type: 4,
    removeDefaultCursor: true,
    color: '#fff',
})